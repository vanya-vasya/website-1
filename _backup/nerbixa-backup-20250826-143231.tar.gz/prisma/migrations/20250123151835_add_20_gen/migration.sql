-- AlterTable
ALTER TABLE "User" ALTER COLUMN "availableGenerations" SET DEFAULT 20;
